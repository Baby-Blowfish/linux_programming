#ifndef COMMON_H
#define COMMON_H

#define MSG "Hello from common.h!\n"

#endif

