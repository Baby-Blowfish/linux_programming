#include <stdio.h>
#include "util.h"

int main() {
    printf("=== This is app1 ===\n");
    print_util();
    return 0;
}

