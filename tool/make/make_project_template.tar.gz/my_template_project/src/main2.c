#include <stdio.h>
#include "util.h"

int main() {
    printf("=== This is app2 ===\n");
    print_util();
    return 0;
}

