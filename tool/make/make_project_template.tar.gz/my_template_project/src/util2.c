#include <stdio.h>
#include "util.h"
#include "common.h"

void print_util() {
    printf("util2: %s", MSG);
}

